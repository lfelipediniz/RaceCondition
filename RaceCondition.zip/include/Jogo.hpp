// jogo.h
#ifndef JOGO_H
#define JOGO_H

#include "Player.hpp"
#include "IA.hpp"
#include <thread>
#include <atomic>
#include <vector>
#include <semaphore>

using namespace std;

class Jogo{
    private:
        Player *jogador;
        mutex pitstopMutex;
        mutex OrdemDeChegada;
        atomic <int> PosicaoDoCarro;


    public:
        vector<thread> threads;
        vector<IA*> IAs;
        vector<Carro*> Carros;

        Jogo(string nomeJogador, char pneuInicial);
        ~Jogo();

        void iniciar();
        void desenharPista(const vector<Carro*> carros);
};

#endif